# sysxinfo
A Simple CLI program for showing system Infos

## Installation
```pip install sysxinfo```

## How to use it?
Open terminal and type sysxinfo

## License

© 2020 Shazin

This repository is licensed under the MIT license. See LICENSE for details.
